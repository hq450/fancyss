### [fancyss](https://github.com/hq450/fancyss/tree/master/fancyss_hnd)

此目录下仅包含代码，不包含离线安装包，离线安装包请前往fancyss_hnd、fancyss_qca、fancyss_arm384目录下载

由于当前fancyss_hnd、fancyss_qca、fancyss_arm384除了二进制文件之间有部分差异，其余基本都是一致的，比如采用相同的软件中心api，且在功能上也是一致的等。

目前维护以上三个目录导致了大量的代码重复，所以fancyss目录里将会将这三者纳入一起来维护，并生成不同的离线安装包。

一起维护后，fancyss_hnd、fancyss_qca、fancyss_arm384的版本号将会统一。





