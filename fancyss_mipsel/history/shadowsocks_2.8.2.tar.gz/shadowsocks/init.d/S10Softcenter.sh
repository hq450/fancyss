#! /bin/sh

echo this is a dummy shell scripts!
echo do not delete it!
